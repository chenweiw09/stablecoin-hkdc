
import threading
from web3 import Web3
from typing import Dict, Optional


class PerAddressNonceManager:
    """
    为单个地址管理 Nonce。这是线程安全的。
    (这是我们之前的 NonceManager，现在改个名字，职责更清晰)
    """

    def __init__(self, w3: Web3, address: str):
        self.w3 = w3
        self.address = Web3.to_checksum_address(address)
        self.lock = threading.Lock()
        # 初始化 nonce 时直接从链上获取
        try:
            self.nonce = self.w3.eth.get_transaction_count(self.address)
            print(f"NonceManager initialized for {self.address}. Starting nonce: {self.nonce}")
        except Exception as e:
            print(f"ERROR: Failed to initialize nonce for {self.address}: {e}")
            self.nonce = 0  # 如果地址是新的，可能会出错，默认为0

    def get_nonce(self) -> int:
        """获取并递增 nonce。这是一个原子操作。"""
        with self.lock:
            # 与链上 nonce 同步，防止外部操作导致 nonce 不一致
            try:
                chain_nonce = self.w3.eth.get_transaction_count(self.address)
                if chain_nonce > self.nonce:
                    print(f"Resyncing nonce for {self.address}. Chain ({chain_nonce}) > Local ({self.nonce})")
                    self.nonce = chain_nonce
            except Exception as e:
                print(f"WARN: Could not resync nonce from chain for {self.address}: {e}")

            current_nonce = self.nonce
            self.nonce += 1
            print(f"Provided nonce: {current_nonce} for address {self.address}")
            return current_nonce


class MultiAddressNonceManager:
    """
    一个线程安全的、管理多个地址 NonceManager 实例的管理器。
    使用字典作为缓存。
    """

    def __init__(self, w3: Web3):
        self.w3 = w3
        self.managers: Dict[str, PerAddressNonceManager] = {}
        self.lock = threading.Lock()  # 用于保护 managers 字典的线程锁

    def get_manager_for_address(self, address: str) -> PerAddressNonceManager:
        """
        获取或创建一个特定地址的 NonceManager 实例。
        """
        checksum_address = Web3.to_checksum_address(address)

        # 先在无锁状态下尝试快速获取，提高性能
        if checksum_address in self.managers:
            return self.managers[checksum_address]

        # 如果不存在，则加锁进行创建
        with self.lock:
            # 双重检查锁定 (Double-Checked Locking) 模式，防止在等待锁时其他线程已创建
            if checksum_address not in self.managers:
                print(f"Creating new nonce manager for address: {checksum_address}")
                self.managers[checksum_address] = PerAddressNonceManager(self.w3, checksum_address)
            return self.managers[checksum_address]

    def get_nonce(self, address: str) -> int:
        """
        为指定地址获取下一个可用的 nonce。
        """
        manager = self.get_manager_for_address(address)
        return manager.get_nonce()
