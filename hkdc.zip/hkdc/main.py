# main.py

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse  # <--- 1. 导入 FileResponse
from fastapi.staticfiles import StaticFiles # <--- 2. 导入 StaticFiles
import os

from flask import Response
from sqlalchemy.orm import Session
from jose import JWTError, jwt
from typing import List
import models
import news
import schemas
import database
import security
import crud
import requests


from blockchain_service import BlockchainService
from news import TrainingMessage

# Create database tables
models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="HKDC Exchange API")

# --- CORS 中间件 (保持不变) ---
origins = [
    "http://localhost",
    "http://localhost:8000",
    "http://127.0.0.1",
    "http://127.0.0.1:8000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


static_file_path = os.path.join(os.path.dirname(__file__), "static")


app.mount("/static", StaticFiles(directory=static_file_path), name="static")


blockchain_service = BlockchainService()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(database.get_db)):
    credentials_exception = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Could not validate credentials", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(token, security.SECRET_KEY, algorithms=[security.ALGORITHM])
        email: str = payload.get("sub")
        if email is None: raise credentials_exception
        user = crud.get_user_by_email(db, email=email)
        if user is None: raise credentials_exception
        return user
    except JWTError:
        raise credentials_exception

# --- 6. 新增：根路径路由，返回登录页面 ---
@app.get("/", include_in_schema=False)
async def read_root():
    """
    当用户访问根URL时，返回前端的 index.html 文件。
    """
    return FileResponse(os.path.join(static_file_path, "index.html"))

# 更新：注册接口
@app.post("/register", response_model=schemas.User, status_code=status.HTTP_201_CREATED)
def register_user(user: schemas.UserCreate, db: Session = Depends(database.get_db)):
    if crud.get_user_by_email(db, email=user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, user=user)


@app.post("/token", response_model=schemas.Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(),
                                 db: Session = Depends(database.get_db)):
    user = crud.get_user_by_email(db, email=form_data.username)
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect username or password")

    access_token = security.create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

# 更新：获取用户信息的接口，现在返回 UserDetails 模型
@app.get("/users/me", response_model=schemas.UserDetails, summary="获取当前用户信息和余额")
def read_users_me(current_user: models.User = Depends(get_current_user), db: Session = Depends(database.get_db)):
    account = crud.get_account_by_user_id(db, user_id=current_user.id)
    # 从区块链查询账户余额
    # amount = blockchain_service.get_balance(current_user.custodial_wallet_address)
    return {
        "user": current_user,
        "account_balance": account.balance if account else 0.0,
        "custodial_wallet_address": current_user.custodial_wallet_address
    }


# 新增：KYC 提交接口
@app.post("/users/me/kyc", response_model=schemas.User, summary="提交KYC信息以激活账户")
def submit_kyc(
        kyc_data: schemas.KYCSumbit,
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    if current_user.status == 'active':
        raise HTTPException(status_code=400, detail="User is already active.")


    # 在真实世界中，这里会调用一个外部服务。我们直接模拟成功。
    liveness_check_passed = True
    if not liveness_check_passed:
        raise HTTPException(status_code=400, detail="Liveness check failed.")
    kms_generated_wallet_address = None
    try:
        print(f"User {current_user.email} passed KYC. Requesting new wallet from KMS...")

        kms_request_body = {
            "key_spec": "ECC_SECP256K1",
            "label": f"user_{current_user.id}_{current_user.email}_wallet"
        }

        # 从 .env 文件获取 KMS URL，这里假设它在 blockchain_service 中
        # 为了解耦，更好的方式是在 main.py 也加载 .env
        kms_url = os.getenv("KMS_SERVICE_URL")
        if not kms_url:
            raise HTTPException(status_code=500, detail="KMS service URL is not configured.")

        # 调用 KMS 的 /keys/generate 接口
        response = requests.post(
            f"{kms_url}/keys/generate",
            json=kms_request_body
        )
        response.raise_for_status()  # 如果请求失败 (非 2xx 状态码)，则抛出异常

        kms_response = response.json()
        kms_generated_wallet_address = kms_response.get("address")

        if not kms_generated_wallet_address:
            raise HTTPException(status_code=500, detail="KMS failed to return a valid address.")

        print(f"KMS successfully generated address: {kms_generated_wallet_address} for user {current_user.email}")
        # 自动增加为白名单用户
        crud.add_to_whitelist(db, whitelist_data=kms_generated_wallet_address)
    except requests.exceptions.RequestException as e:
        # 处理调用 KMS 失败的情况
        print(f"ERROR: Failed to call KMS service - {e}")
        error_detail = e.response.json().get("detail") if e.response else str(e)
        raise HTTPException(status_code=503,
                            detail=f"Could not create wallet: KMS service unavailable or failed. ({error_detail})")

    try:
        updated_user = crud.submit_kyc_info(db, user_id=current_user.id, kyc_data=kyc_data,
            wallet_address=kms_generated_wallet_address)
        if not updated_user:
            raise HTTPException(status_code=404, detail="User not found.")
        return updated_user
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put("/users/me/activate", response_model=schemas.User, summary="[Simulation] Activate user after KYC")
def activate_user(current_user: schemas.User = Depends(get_current_user), db: Session = Depends(database.get_db)):
    if current_user.status == 'active':
        raise HTTPException(status_code=400, detail="User is already active")
    return crud.update_user_status(db, user_id=current_user.id, status='active')


@app.get("/purchase/payment-info/{payment_method}", summary="获取交易所收款信息")
def get_payment_info(payment_method: str, current_user: models.User = Depends(get_current_user)):
    """
    根据支付方式（alipay/wechat）返回收款信息。
    """
    if payment_method.lower() == 'alipay':
        return {
            "method": "Alipay",
            "account_name": "测试交易所账户名字",
            "account_id": "alipay_account"
        }
    elif payment_method.lower() == 'wechat':
         return {
            "method": "WeChat Pay",
            "account_name": "测试交易所账户名字",
            "account_id": "wechat_account"
        }
    raise HTTPException(status_code=404, detail="Payment method not supported.")


# --- 新增：购买/充值预校验接口 ---
@app.post("/purchase/pre-check", summary="购买/充值前置安全校验")
def purchase_pre_check(
        request: schemas.DepositBankRequest,  # 复用 schema 来获取金额
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    """
    在用户进行支付前，执行所有必要的后端校验。
    如果所有检查都通过，返回成功；否则，返回具体的失败原因。
    """
    # 1. 验证用户状态
    if current_user.status != 'active':
        raise HTTPException(status_code=403, detail="您的账户尚未激活 (未通过KYC)，无法进行购买。")

    # 2. 验证用户是否有托管钱包地址
    if not current_user.custodial_wallet_address:
        raise HTTPException(status_code=400, detail="系统错误：未找到您的托管钱包地址，请联系客服。")

    # 3. 核心：校验用户的托管钱包地址是否在全局白名单中且状态正常
    recipient_wallet_address = current_user.custodial_wallet_address
    whitelisted_address = crud.get_whitelist_address_by_address(db, address=recipient_wallet_address)

    if not whitelisted_address:
        print(f"CRITICAL ERROR: User wallet '{recipient_wallet_address}' NOT in whitelist!")
        raise HTTPException(
            status_code=403,
            detail="安全风险：您的收款钱包地址未被系统识别，请联系客服以保障您的资产安全。"
        )

    if whitelisted_address.status == 'frozen':
        print(f"SECURITY ALERT: Deposit attempt to frozen address '{recipient_wallet_address}'.")
        raise HTTPException(
            status_code=403,
            detail="安全风险：您的收款钱包地址已被冻结，请联系客服。"
        )

    # 4. (可选) 可以在这里增加其他风控检查，例如单日充值限额等

    # 5. 如果所有检查都通过
    return {"status": "ok", "message": "Pre-check passed. Ready for payment."}


@app.post("/purchase/confirm", summary="确认购买成功 (模拟支付回调)")
def confirm_purchase(
        request: schemas.DepositBankRequest,  # 复用 schema
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    """
    用户完成支付后，前端调用此接口为用户入账。
    """
    if current_user.status != 'active':
        raise HTTPException(status_code=403, detail="User is not active.")
    try:
        # **触发区块链服务，从交易所热钱包向用户托管钱包转账**
        tx_receipt = blockchain_service.transfer(
            sender_label = blockchain_service._get_owner_label(),
            recipient_address=current_user.custodial_wallet_address,
            amount=request.amount
        )
        tx_hash = tx_receipt.transactionHash.hex()
        print(f"交易成功区块 hash '{tx_hash}'")
        # **链上成功后，才更新内部记账余额并记录交易**
        updated_account = crud.update_balance(db, user_id=current_user.id, amount=request.amount)
        crud.create_transaction(
            db, initiator_user_id=current_user.id, type="purchase_hkdc",
            amount=request.amount, status="completed", tx_hash=tx_hash,
            # 记录收款地址是用户的托管钱包
            recipient_web3_address=current_user.custodial_wallet_address
        )
        return {
            "message": "HKDC purchase successful. Tokens have been transferred to your managed wallet.",
            "new_balance": updated_account.balance,
            "tx_hash": tx_hash
        }
    except Exception as e:
        print(f"异常类型：{type(e).__name__}, 错误信息：{e}")
        # 如果链上转账失败，用户的内部余额不会改变
        raise HTTPException(status_code=500, detail=f"On-chain transfer failed: {e}")



@app.get("/deposit/web3/address")
def get_web3_deposit_address():
    return {"deposit_address": blockchain_service.platform_owner_address}


@app.post("/sell", summary="卖出HKDC (提现到银行卡)")
def sell_hkdc(
        request: schemas.WithdrawBankRequest,  # 复用 schema
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    if current_user.status != 'active':
        raise HTTPException(status_code=403, detail="User is not active.")

    account = crud.get_account_by_user_id(db, user_id=current_user.id)
    if not account or account.balance < request.amount:
        raise HTTPException(status_code=400, detail="Insufficient balance.")

    bank_accounts = crud.get_bank_accounts_by_user_id(db, user_id=current_user.id)
    if request.bank_account_id not in [card.id for card in bank_accounts]:
        raise HTTPException(status_code=403, detail="Bank account does not belong to the user.")

    # 增加真实的区块链转账交易
    try:
        label = f"user_{current_user.id}_{current_user.email}_wallet"
        # **触发区块链服务，从交易所热钱包向用户托管钱包转账**
        tx_receipt = blockchain_service.transfer(
            sender_label=label,
            recipient_address=blockchain_service.platform_owner_address,
            amount=request.amount
        )
        tx_hash = tx_receipt.transactionHash.hex()
        print(f"交易成功区块 hash '{tx_hash}'")
        # **链上成功后，才更新内部记账余额并记录交易**
        updated_account = crud.update_balance(db, user_id=current_user.id, amount=-request.amount)
        crud.create_transaction(
            db, initiator_user_id=current_user.id, type="sell_hkdc",
            amount=request.amount, status="completed", tx_hash=tx_hash,

        )
        # return {
        #     "message": "HKDC purchase successful. Tokens have been transferred to your managed wallet.",
        #     "new_balance": updated_account.balance,
        #     "tx_hash": tx_hash
        # }
        return {"message": "Sell order placed successfully."}
    except Exception as e:
        print(f"异常类型：{type(e).__name__}, 错误信息：{e}")
        # 如果链上转账失败，用户的内部余额不会改变
        raise HTTPException(status_code=500, detail=f"On-chain transfer failed: {e}")


@app.post("/transfer", summary="执行内部转账")
def internal_transfer(
        request: schemas.TransferRequest,
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    """
    执行用户间的内部转账，并增加对收款方的验证。
    """
    # 1. 验证发起方 (当前用户) 状态和余额
    if current_user.status != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account is not active. Please complete KYC."
        )

    sender_account = crud.get_account_by_user_id(db, user_id=current_user.id)
    if not sender_account or sender_account.balance < request.amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    # 2. 验证收款方账户
    if request.recipient_email == current_user.email:
        raise HTTPException(status_code=400, detail="Cannot transfer to yourself.")

    recipient_user = crud.get_user_by_email(db, email=request.recipient_email)

    # 2a. 检查收款方账户是否存在
    if not recipient_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Recipient account does not exist."
        )

    # 2b. 检查收款方账户状态是否为 'active' (已认证)
    if recipient_user.status != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Recipient account is at risk (not verified). Transfer aborted."
        )
    # 3. 执行转账操作 (如果所有验证都通过)
    crud.update_balance(db, user_id=current_user.id, amount=-request.amount)
    crud.update_balance(db, user_id=recipient_user.id, amount=request.amount)

    # 4. 创建详细的交易记录
    crud.create_transaction(
        db, initiator_user_id=current_user.id, recipient_user_id=recipient_user.id,
        type="internal_transfer", amount=request.amount, status="completed"
    )

    return {"message": "Transfer successful"}


@app.post("/transfer/web3", summary="转账到Web3钱包 (原提现)")
def transfer_to_web3(
        request: schemas.WithdrawWeb3Request,  # 复用 schema
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    if current_user.status != 'active':
        raise HTTPException(status_code=403, detail="User is not active.")

    account = crud.get_account_by_user_id(db, user_id=current_user.id)
    if not account or account.balance < request.amount:
        raise HTTPException(status_code=400, detail="Insufficient balance.")

    # 2a. 检查收款方账户是否存在
    recipient_user = crud.get_user_by_email(db, email=request.recipient_account)
    if not recipient_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Recipient account does not exist."
        )

    # 2b. 检查收款方账户状态是否为 'active' (已认证)
    if recipient_user.status != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Recipient account is at risk (not verified). Transfer aborted."
        )
    if recipient_user.custodial_wallet_address != request.recipient_web3_address:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Recipient web3 address wrong. Transfer aborted."
        )

    # 白名单校验
    whitelisted_address = crud.get_whitelist_address_by_address(db, address=request.recipient_web3_address)
    if not whitelisted_address or whitelisted_address.status == 'frozen':
        raise HTTPException(
            status_code=403,
            detail="The recipient Web3 address is invalid or frozen."
        )

    try:
        label = f"user_{current_user.id}_{current_user.email}_wallet"
        # **触发区块链服务，从交易所热钱包向用户托管钱包转账**
        tx_receipt = blockchain_service.transfer(
            sender_label=label,
            recipient_address=request.recipient_web3_address,
            amount=request.amount
        )
        tx_hash = tx_receipt.transactionHash.hex()
        print(f"交易成功区块 hash '{tx_hash}'")
        crud.update_balance(db, user_id=current_user.id, amount=-request.amount)
        crud.update_balance(db, user_id=recipient_user.id, amount=+request.amount)
        crud.create_transaction(
            db, initiator_user_id=current_user.id,
            type="transfer_web3",
            amount=request.amount,
            status="completed",
            recipient_user_id= recipient_user.id,
            recipient_web3_address=request.recipient_web3_address,
            tx_hash=tx_hash,
            initiator_web3_address=current_user.custodial_wallet_address
        )

        return {"message": "Web3 transfer successful", "tx_hash": tx_hash}
    except Exception as e:
        print(f"异常类型：{type(e).__name__}, 错误信息：{e}")
        crud.create_transaction(
            db, initiator_user_id=current_user.id,
            type="transfer_web3",
            amount=request.amount,
            status="failed",
            recipient_user_id=recipient_user.id,
            recipient_web3_address=request.recipient_web3_address,
            initiator_web3_address=current_user.custodial_wallet_address
        )

        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")



@app.get("/transactions/history", response_model=List[schemas.TransactionDetail], summary="获取当前用户的交易历史")
def get_transaction_history(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(database.get_db)
):
    return crud.get_transactions_by_user_id(db, user_id=current_user.id)


@app.get("/users/me/bank-accounts", response_model=List[schemas.BankAccount], summary="获取当前用户绑定的银行卡列表")
def read_user_bank_accounts(
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    """
    获取当前登录用户所有已绑定的银行卡信息。
    """
    return crud.get_bank_accounts_by_user_id(db, user_id=current_user.id)


@app.post("/users/me/bank-accounts", response_model=schemas.BankAccount, status_code=status.HTTP_201_CREATED,
          summary="为当前用户添加新的银行卡")
def add_user_bank_account(
        bank_account: schemas.BankAccountCreate,
        current_user: models.User = Depends(get_current_user),
        db: Session = Depends(database.get_db)
):
    """
    为当前登录用户绑定一张新的银行卡。
    """
    # 检查用户是否已激活 (KYC通过)
    if current_user.status != 'active':
        raise HTTPException(status_code=403, detail="User is not active. Please complete KYC first.")

    # 检查卡号是否已被其他人绑定
    db_bank_account = crud.get_bank_account_by_card_number(db, card_number=bank_account.card_number)
    if db_bank_account:
        raise HTTPException(status_code=400, detail="Bank card number already registered.")

    return crud.create_bank_account(db=db, bank_account=bank_account, user_id=current_user.id)

@app.get("/admin/whitelist", response_model=List[schemas.WhitelistAddress], summary="[Admin] 获取全局提现地址白名单")
def read_global_whitelist(db: Session = Depends(database.get_db)):
    return crud.get_all_whitelist_addresses(db)

@app.post("/admin/whitelist", response_model=schemas.WhitelistAddress, status_code=status.HTTP_201_CREATED, summary="[Admin] 添加新地址到全局白名单")
def add_address_to_global_whitelist(
    whitelist_data: schemas.WhitelistAddressCreate,
    db: Session = Depends(database.get_db)
):
    if not whitelist_data.address.startswith("0x") or len(whitelist_data.address) != 42:
        raise HTTPException(status_code=400, detail="Invalid Ethereum address format.")
    if crud.get_whitelist_address_by_address(db, address=whitelist_data.address):
        raise HTTPException(status_code=400, detail="Address already in whitelist.")
    return crud.add_to_whitelist(db, whitelist_data=whitelist_data)

@app.put("/admin/whitelist/{address_id}/status", response_model=schemas.WhitelistAddress, summary="[Admin] 更新白名单地址状态")
def update_whitelist_status(
    address_id: int,
    status_update: schemas.WhitelistAddressStatusUpdate,
    db: Session = Depends(database.get_db)
):
    if status_update.status not in ['normal', 'frozen']:
        raise HTTPException(status_code=400, detail="Invalid status. Must be 'normal' or 'frozen'.")
    updated_address = crud.update_whitelist_address_status(db, address_id=address_id, status=status_update.status)
    if not updated_address:
        raise HTTPException(status_code=404, detail="Whitelist address not found.")
    return updated_address

@app.get("/news", response_model=List[TrainingMessage], summary="获取实训消息轮播列表")
async def get_training_messages():
    """
    提供一个用于前端轮播组件的消息列表。
    """
    return news.mock_messages

@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    """
    提供一个空的响应来处理浏览器对 favicon.ico 的自动请求。
    """
    return Response(status_code=204)

# # --- 用于本地开发直接运行 ---
if __name__ == '__main__':
    import uvicorn
    # 这里的 "main:app" 字符串告诉 uvicorn：
    # - "main" 指的是 main.py 文件
    # - "app" 指的是在该文件中创建的 FastAPI 实例 `app = FastAPI()`
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)