from pydantic import BaseModel
from typing import List
from datetime import datetime

class TrainingMessage(BaseModel):
    id: int
    title: str
    content: str
    created_at: datetime

# 2. 创建一个模拟的消息列表 (在实际应用中，这些数据应来自数据库)
mock_messages: List[TrainingMessage] = [
    TrainingMessage(
        id=1,
        title="系统安全提示",
        content="请定期更新您的登录密码，切勿向他人透露您的私钥或助记词。我们的工作人员绝不会向您索要密码。",
        created_at=datetime.now()
    ),
    TrainingMessage(
        id=2,
        title="HKDC v1.1 版本上线通知",
        content="新版本已优化链上转账的 Gas 估算，并增强了交易历史记录的展示。感谢您的支持！",
        created_at=datetime.now()
    ),
    TrainingMessage(
        id=3,
        title="关于近期网络钓鱼的风险警告",
        content="警惕任何要求您点击链接并输入敏感信息的邮件或消息。请认准我们的官方域名。",
        created_at=datetime.now()
    )
]