import os
import json
from web3 import Web3

from dotenv import load_dotenv
import requests
from hexbytes import HexBytes
from typing import Optional, Dict, Any

from nonceManager import MultiAddressNonceManager

# 加载 .env 文件中的环境变量
load_dotenv()


class BlockchainService:
    def __init__(self):
        self.w3 = Web3(Web3.HTTPProvider(os.getenv("SEPOLIA_RPC_URL")))
        if not self.w3.is_connected():
            raise ConnectionError("无法连接到以太坊节点")

        self.chain_id = self.w3.eth.chain_id

        # --- 2. 加载合约信息 ---
        self.contract_address = Web3.to_checksum_address(os.getenv("HKDC_CONTRACT_ADDRESS"))
        with open('abi.json', 'r') as f:
            abi = json.load(f)
        self.contract = self.w3.eth.contract(address=self.contract_address, abi=abi)
        self.decimals = self.contract.functions.decimals().call()
        print(f"✅ 合约已加载，地址: {self.contract_address}")

        # 平台所有者/管理员地址，用于发起平台自身的交易（如铸币、从平台地址转账）
        self.platform_owner_address = Web3.to_checksum_address(os.getenv("ADMIN_WALLET_ADDRESS"))
        self.platform_owner_key_id = os.getenv("HOST_LABEL")

        # 平台Gas代付者地址，用于支付用户元交易的Gas费
        self.platform_sponsor_address = Web3.to_checksum_address(os.getenv("ADMIN_WALLET_ADDRESS"))
        self.platform_sponsor_key_id = os.getenv("HOST_LABEL")
        print(f"平台所有者地址: {self.platform_owner_address}")
        print(f"平台Gas代付地址: {self.platform_sponsor_address}")

        self.kms_url = os.getenv("KMS_SERVICE_URL")
        self.nonce_manager = MultiAddressNonceManager(self.w3)
        print("Blockchain Service Initialized.")

    def _format_to_wei(self, amount: float) -> int:
        return int(amount * (10 ** self.decimals))

    def transfer(self, sender_label: str, recipient_address: str, amount: float):
        """
        统一的转账入口函数。
        - 如果发起方是平台所有者，则执行直接转账，平台自己支付Gas。
        - 如果发起方是普通用户，则执行元交易，由平台代付Gas。
        """
        print(f"\n开始处理转账请求: 从 '{sender_label}' -> {recipient_address}，金额: {amount}")
        return self._execute_direct_transfer(sender_label, recipient_address, amount)
        # if sender_label == self.platform_owner_key_id:
        #     return self._execute_direct_transfer(sender_label, recipient_address, amount)
        # else:
        #     return self._execute_sponsored_transfer(sender_label, recipient_address, amount)

    def _execute_direct_transfer(self, owner_label: str, recipient_address: str, amount: float) -> Dict[str, Any]:
        """
        场景1: 平台Owner作为发起方，直接执行交易并支付Gas。
        """
        print(f"模式: 直接交易。发起方为平台所有者 '{owner_label}'。")

        # 1. 获取Owner的链上信息
        owner_info = self._get_key_info_by_label(owner_label)
        owner_address = owner_info["address"]
        owner_key_id = owner_info["key_id_str"]

        # 2. 构建合约调用
        value_in_wei = self._format_to_wei(amount)
        function_call = self.contract.functions.transfer(
            Web3.to_checksum_address(recipient_address),
            value_in_wei
        )

        # 3. 构建完整的交易字典
        tx_dict = function_call.build_transaction({
            'from': owner_address,
            'value': 0,
            'gas': function_call.estimate_gas({'from': owner_address}),
            'gasPrice': self.w3.eth.gas_price,
            'nonce': self.w3.eth.get_transaction_count(Web3.to_checksum_address(owner_address)),
            'chainId': self.chain_id
        })

        # 4. 签名并发送
        signed_tx_data = self._sign_with_kms(owner_key_id, tx_dict)
        raw_tx = HexBytes(signed_tx_data["raw_transaction"])

        tx_hash = self.w3.eth.send_raw_transaction(raw_tx)
        print(f"交易已发送，哈希: {tx_hash.hex()}")

        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash)
        if receipt.status != 1:
            raise RuntimeError(f"直接交易执行失败，哈希: {tx_hash.hex()}")

        print(f"直接交易成功确认，区块号: {receipt.blockNumber}")
        return receipt

    def _execute_sponsored_transfer(self, user_label: str, recipient_address: str, amount: float) -> Dict[str, Any]:
        """
        场景2: 普通用户作为发起方，由Sponsor代付Gas。
        """
        print(f"模式: Gas代付元交易。发起方为用户 '{user_label}'。")

        # --- Part 1: 用户对意图进行签名 ---
        print("步骤 1/2: 请求用户签名...")
        user_info = self._get_key_info_by_label(user_label)
        user_address = user_info["address"]
        user_key_id = user_info["key_id_str"]

        value_in_wei = self._format_to_wei(amount)
        transfer_call = self.contract.functions.transfer(
            Web3.to_checksum_address(recipient_address),
            value_in_wei
        )

        # 构建元交易数据（这将被用户签名）
        meta_tx_dict = {
            'from': user_address,
            'to': self.contract_address,
            'value': 0,
            'gas': 1_000_000,  # 估算值，实际由Sponsor支付
            'gasPrice': self.w3.eth.gas_price,
            'nonce': self.w3.eth.get_transaction_count(Web3.to_checksum_address(user_address)),  # 这里可以是用户的链上或链下nonce
            'data': transfer_call.build_transaction({'from': user_address})['data'],
            'chainId': self.chain_id
        }

        # 使用KMS获取用户对元交易的签名
        signed_meta_tx = self._sign_with_kms(user_key_id, meta_tx_dict)
        user_signature = signed_meta_tx["raw_transaction"]  # 合约需要解析此签名
        print("用户签名成功。")

        # --- Part 2: Sponsor打包交易并支付Gas ---
        print("步骤 2/2: 由Sponsor打包交易并代付Gas...")
        sponsor_info = self._get_key_info_by_label(self.platform_sponsor_key_id)
        sponsor_address = sponsor_info["address"]
        sponsor_key_id = sponsor_info["key_id_str"]

        # 构建调用合约 executeMetaTransaction 的函数
        # 注意: 合约函数名和参数需与您的合约完全一致！
        execute_call = self.contract.functions.executeMetaTransaction(
            user_address,
            meta_tx_dict['data'],
            HexBytes(user_signature)  # 确保参数类型与合约匹配
        )

        # 构建Sponsor需要签名的真实交易
        sponsor_tx_dict = execute_call.build_transaction({
            'from': sponsor_address,
            'value': 0,
            'gas': execute_call.estimate_gas({'from': sponsor_address}),
            'gasPrice': self.w3.eth.gas_price,
            'nonce': self.w3.eth.get_transaction_count(Web3.to_checksum_address(sponsor_address)),
            'chainId': self.chain_id
        })

        # Sponsor签名并发送
        signed_sponsor_tx = self._sign_with_kms(sponsor_key_id, sponsor_tx_dict)
        raw_sponsor_tx = HexBytes(signed_sponsor_tx["raw_transaction"])

        tx_hash = self.w3.eth.send_raw_transaction(raw_sponsor_tx)
        print(f"Sponsor交易已发送，哈希: {tx_hash.hex()}")

        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash)
        if receipt.status != 1:
            raise RuntimeError(f"Sponsor代付交易执行失败，哈希: {tx_hash.hex()}")

        print(f"Sponsor代付交易成功确认，区块号: {receipt.blockNumber}")
        return receipt

    def _get_key_info_by_label(self, label: str) -> Dict[str, str]:
        """通过标签从KMS获取密钥的 key_id 和 address。"""
        print(f"查询KMS: 获取标签为 '{label}' 的密钥信息...")
        kms_info_url = f"{self.kms_url}/keys/{label}"
        response = requests.get(kms_info_url)
        response.raise_for_status()
        keys_list = response.json()
        if not keys_list:
            raise ValueError(f"错误: 在KMS中找不到标签为 '{label}' 的密钥。")

        key_data = keys_list[0]  # 假设一个标签只对应一个密钥
        return {"key_id_str": key_data["label"], "address": key_data["address"]}

    def _sign_with_kms(self, key_id_str: str, tx_dict: Dict) -> Dict:
        """
        使用KMS对交易字典进行签名。
        内置了处理 'from' -> 'from_' 键名转换的核心逻辑。
        """
        # 1. 准备载荷 (Payload)
        payload = tx_dict.copy()

        # 2. [关键] 将 'from' 键重命名为 'from_' 以匹配KMS模型
        if 'from' in payload:
            payload['from_'] = payload.pop('from')

        # 3. 调用KMS签名
        sign_url = f"{self.kms_url}/sign/{key_id_str}"
        print(f"请求KMS签名: URL={sign_url}")

        response = requests.post(sign_url, json=payload)

        if response.status_code == 422:
            print("错误: 422 Unprocessable Entity。KMS模型验证失败。")
            print("发送的载荷:", payload)
            print("服务器返回内容:", response.text)

        response.raise_for_status()
        return response.json()

    def _get_owner_label(self):
        return self.platform_owner_key_id

    def get_balance(self, account_address: str) -> float:
        """
        查询指定账户地址的 HKDC 余额。

        :param account_address: 要查询的以太坊地址字符串。
        :return: 格式化后的余额 (浮点数)。
        """
        print(f"查询余额: 正在获取地址 {account_address} 的余额...")
        try:
            # 1. 将地址字符串转换为 checksum 格式，这是 web3.py 的最佳实践
            checksum_address = Web3.to_checksum_address(account_address)

            # 2. 调用合约的 balanceOf 函数
            #    .call() 表示这是一个只读操作，不会消耗 Gas
            balance_in_wei = self.contract.functions.balanceOf(checksum_address).call()

            # 3. 将从合约返回的原始余额（最小单位）根据小数位数进行转换
            #    例如：余额是 5000000，decimals 是 6，则实际金额是 5.00
            formatted_balance = balance_in_wei / (10 ** self.decimals)

            print(f"查询成功: 地址 {account_address} 的余额是 {formatted_balance} HKDC")
            return formatted_balance

        except Exception as e:
            print(f"错误: 查询地址 {account_address} 的余额失败。原因: {e}")
            raise  # 重新抛出异常，以便上层调用者可以处理

    def is_whitelisted(self, account_address: str) -> bool:
        """
        查询指定的账户地址是否在白名单中。

        :param account_address: 要查询的以太坊地址字符串。
        :return: 如果地址在白名单中，则返回 True，否则返回 False。
        """
        print(f"查询白名单: 正在检查地址 {account_address}...")
        try:
            # 1. 转换地址为 Checksum 格式
            checksum_address = Web3.to_checksum_address(account_address)

            # 2. 调用合约的 isWhitelisted 函数
            is_on_list = self.contract.functions.isWhitelisted(checksum_address).call()

            print(f"查询成功: 地址 {account_address} 的白名单状态是: {is_on_list}")
            return is_on_list

        except Exception as e:
            print(f"错误: 查询地址 {account_address} 的白名单状态失败。原因: {e}")
            raise