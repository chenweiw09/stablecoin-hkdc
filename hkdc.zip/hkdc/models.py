from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, func
from sqlalchemy.orm import relationship
from database import Base

# 定义一些常用的长度常量，便于维护
LEN_EMAIL = 255
LEN_NAME = 100
LEN_ID_CARD = 50
LEN_PASSWORD_HASH = 255
LEN_STATUS = 50
LEN_ADDRESS = 42  # Ethereum address length
LEN_TX_HASH = 66  # Transaction hash length
LEN_CARD_NUMBER = 50
LEN_BANK_NAME = 100
LEN_LABEL = 100


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(LEN_EMAIL), unique=True, index=True, nullable=False)
    full_name = Column(String(LEN_NAME), index=True, nullable=True)
    identity_card_number = Column(String(LEN_ID_CARD), unique=True, index=True, nullable=True)
    hashed_password = Column(String(LEN_PASSWORD_HASH), nullable=False)
    status = Column(String(LEN_STATUS), default="unverified", nullable=False)
    custodial_wallet_address = Column(String(LEN_PASSWORD_HASH), nullable=True)
    account = relationship("Account", back_populates="owner", uselist=False, cascade="all, delete-orphan")
    bank_accounts = relationship("BankAccount", back_populates="owner", cascade="all, delete-orphan")


class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    balance = Column(Float, default=0.0)
    user_id = Column(Integer, ForeignKey("users.id"))
    owner = relationship("User", back_populates="account")


class BankAccount(Base):
    __tablename__ = "bank_accounts"
    id = Column(Integer, primary_key=True, index=True)
    account_name = Column(String(LEN_NAME), nullable=False)
    bank_name = Column(String(LEN_BANK_NAME), nullable=False)
    card_number = Column(String(LEN_CARD_NUMBER), unique=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    owner = relationship("User", back_populates="bank_accounts")


class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    initiator_user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    recipient_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    initiator_web3_address = Column(String(LEN_ADDRESS), nullable=True)
    recipient_web3_address = Column(String(LEN_ADDRESS), nullable=True)
    bank_account_id = Column(Integer, ForeignKey("bank_accounts.id"), nullable=True)
    type = Column(String(LEN_STATUS), nullable=False)
    amount = Column(Float, nullable=False)
    tx_hash = Column(String(LEN_TX_HASH), nullable=True, unique=True)
    status = Column(String(LEN_STATUS), default="completed", nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), onupdate=func.now())
    initiator = relationship("User", foreign_keys=[initiator_user_id])
    recipient = relationship("User", foreign_keys=[recipient_user_id])
    bank_account = relationship("BankAccount")


class WithdrawalWhitelist(Base):
    __tablename__ = "withdrawal_whitelist"
    id = Column(Integer, primary_key=True, index=True)
    address = Column(String(LEN_ADDRESS), unique=True, index=True, nullable=False)
    label = Column(String(LEN_LABEL), nullable=False)
    status = Column(String(LEN_STATUS), default="normal", nullable=False)
    frozen_at = Column(DateTime(timezone=True), nullable=True)
